import { Component } from "@stencil/core";

@Component({
  styleUrl: "app-root.css",
  tag :  "app-root",
})
export class AppRoot {

  public render() {
    return (
      <div>
        <header>
        
        </header>

        <main>
          <div class="container">
            <div class="row">
              <div class="col-12">
                Hello world!
              </div>
            </div>     
          </div>     
        </main>
      </div>
    );
  }
}
